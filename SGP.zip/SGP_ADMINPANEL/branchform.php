<?php
session_start();
 if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
  {
   header("location:/sgp/sgp_adminpanel/loginPage.php");
   exit;
  }
?>
<?php
 $response = false;
 $showError = false;
 if($_SERVER['REQUEST_METHOD'] == "POST")
 {
    require 'db.php';
    $branch_code = $_POST['branch_code'];
    $name = $_POST['name'];
    $business_name = $_POST['business_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pin_code = $_POST['pin_code'];
    $ifsc_code = $_POST['ifsc_code'];
    $bank_acc_name = $_POST['bank_acc_name'];
    $bank_acc_no = $_POST['bank_acc_no'];
    $acc_type = $_POST['acc_type'];      

        $sql = "INSERT INTO `branchform`(`branch_code`, `name`, `business_name`, `mobile`, `email`, `address`, `city`, `state`, `pin_code`, `ifsc_code`, `bank_acc_name`, `bank_acc_no`, `acc_type`, `date`) VALUES ('$branch_code','$name', '$business_name','$mobile','$email','$address','$city','$state','$pin_code','$ifsc_code','$bank_acc_name','$bank_acc_no','$acc_type', current_timestamp())"; 
        $result = mysqli_query($conn,$sql);
        if($result)
        {
            $response = true;
        }
        else
        {
             $showError = "Invalid Credentials!";
        }
 }
?>
<!DOCTYPE html>
<html>
	<head>
      <!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>CREATE BRANCH</title>
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!--
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

	</head>
    <body>
        <?php
           require 'nav.php';
        ?>

        <?php 
        if($response == true)
        {
          echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>SUCCESS! </strong> Your Lead is created successfully.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
        if($showError == true)
        {
          echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>ERROR!</strong> '. $showError.'
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
       ?> 

       <div class="container my-4">
       <h1 class="text-center"> CREATE BRANCH</h1>
        <form class="was-validated" action="branchform.php" method="POST">
          <div class="mb-3 form-group">
            <label for="validationtext" class="form-label">BRANCH CODE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="branch_code" placeholder="BRANCH CODE" required></input>          
        </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">FULL NAME</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="name" placeholder="Full name" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">BUSINESS NAME</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="business_name" placeholder="Business NAME" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">MOBILE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="mobile" placeholder="Mobile" maxlength="10" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">EMAIL ID</label>
            <input type="email" class="form-control is-invalid" id="validationtext" name="email" placeholder="Email Id" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">ADDRESS</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="address" placeholder="Address" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">CITY</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="city" placeholder="City" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">STATE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="state" placeholder="State" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">PIN CODE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="pin_code" placeholder="Pin Code" maxlength="6" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">IFSC CODE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="ifsc_code" placeholder="Ifsc code" maxlength="11" required></input>
          </div>       

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">BANK A/C NAME</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="bank_acc_name" placeholder="Bank a/c name" required></input>
          </div>

         
        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">BANK A/C NO</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="bank_acc_no" placeholder="Bank a/c no" maxlength="18" required></input>
          </div>
       
               
        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">A/C TYPE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="acc_type" placeholder="A/C type" required></input>
          </div>
        
          <div class="mb-3">
            <center>
            <button class="btn btn-primary" type="submit">Submit form</button>
            <button class="btn btn-primary" type="cancel">Cancel</button>
        </center>
          </div>

          
        </form>
    </div
    >
    </body>
</html>