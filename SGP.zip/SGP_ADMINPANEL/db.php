<?php
  $username = "root";
  $password = "";
  $database = "sgp_adminpanel";
  $server = "localhost";

  $conn = mysqli_connect($server,$username,$password,$database);

  if(!$conn)
  {
  	echo "Error ".mysqli_connect_error(); 
  }
?>