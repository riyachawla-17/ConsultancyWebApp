<?php
session_start();
 if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
  {
   header("location:/sgp/sgp_adminpanel/loginPage.php");
   exit;
  }
?>
<?php
 $response = false;
 $showError = false;
 if($_SERVER['REQUEST_METHOD'] == "POST")
 {
    require 'db.php';
    header('refresh:0');
    $branch_code = $_POST['branch_code'];
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $doj = $_POST['doj'];
    $ctc_offered = $_POST['ctc_offered'];  

        $sql = "INSERT INTO `employeeform`(`branch_code`, `name`, `mobile`, `email`, `doj`, `ctc_offered`, `date`) VALUES ('$branch_code','$name','$mobile','$email','$doj','$ctc_offered', current_timestamp())"; 
        $result = mysqli_query($conn,$sql);
        if($result)
        {
            $response = true;
        }
        else
        {
             $showError = "Invalid Credentials!";
        }
 }
?>
<!DOCTYPE html>
<html>
	<head>
      <!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>CREATE EMPLOYEE</title>
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!--
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

	</head>
    <body>
        <?php
           require 'nav.php';
        ?>

        <?php 
        if($response == true)
        {
          echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>SUCCESS! </strong> Your Lead is created successfully.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
        if($showError == true)
        {
          echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>ERROR!</strong> '. $showError.'
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
       ?> 

       <div class="container my-4">
       <h1 class="text-center"> CREATE EMPLOYEE</h1>
        <form class="was-validated" action="employeeform.php" method="POST">
          <div class="mb-3 form-group">
            <label for="validationtext" class="form-label">EMPLOYEE CODE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="branch_code" placeholder="BRANCH CODE" required></input>          
        </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">FULL NAME</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="name" placeholder="Full name" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">MOBILE</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="mobile" placeholder="Mobile" maxlength="10" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">EMAIL ID</label>
            <input type="email" class="form-control is-invalid" id="validationtext" name="email" placeholder="Email Id" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">DATE OF JOINING</label>
            <input type="date" class="form-control is-invalid" id="validationtext" name="doj" placeholder="Date of Joining" required></input>
          </div>

        <form class="was-validated">
          <div class="mb-3">
            <label for="validationtext" class="form-label">CTC OFFERED</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="ctc_offered" placeholder="Ctc offered" required></input>
          </div>
        
          <div class="mb-3">
            <center>
            <button class="btn btn-primary" type="submit">Submit form</button>
            <button class="btn btn-primary" type="cancel">Cancel</button>
        </center>
          </div>

          
        </form>
    </div
    >
    </body>
</html>