<?php
   $login = false;
   $showError = false;
   if($_SERVER["REQUEST_METHOD"] == "POST")
   {
   include 'db.php';
   $username = $_POST['username'];   
   $password = md5($_POST['pass1']);
        $sql = "SELECT * FROM `AdminLogin` WHERE username='$username' AND password='$password'";
      //  $sql = "SELECT * FROM `AdminLogin` WHERE username='$username'";
        $result = mysqli_query($conn,$sql);
        $num = mysqli_num_rows($result);
        if($num == 1)
        {
            while($row = mysqli_fetch_assoc($result))
            {
              if ($password == $row['password'])
              {
                $login = true;
                session_start();
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;
                header("location:home.php");   
              }
            
            else
            {
              $showError ="Invalid Credentials! 1";
            }
          }
       }
       else
        {
            $showError =  "Invalid Credentials! 2";
        }
    }

?>

<!DOCTYPE html>
<html>
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>LOGIN</title>
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

   </head>
        <body>
        <?php
           require 'nav.php';
        ?> 

      <?php 
        if($login == true)
        {
          echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>SUCCESS! </strong> You are now logged in.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
        if($showError)
        {
          echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>ERROR!</strong> '. $showError.'
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
       ?>
       <div class="container my-4">
            <h1 class="text-center"> Log In to our website </h1>

            <form action = "/sgp/loginPage.php" method="POST">
            <div class="form-group">
            <label for="exampleInputEmail1">Username</label>
            <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username">
            </div>
           
            <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" id="pass1" name="pass1" placeholder="Password">
            </div>
  
            <button type="submit" class="btn btn-primary">LogIn</button>
            </form>

        </div>

    </body>
</html>
