<?php
session_start();
 if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
  {
   header("location:/sgp/sgp_adminpanel/loginPage.php");
   exit;
  }
?>
<!DOCTYPE html>
<html>
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title> VIEW EMPLOYEE LEADS </title>
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

   </head>
   <body>
      <?php
         require 'db.php';
         require 'nav.php';
      ?>

<div class="container-fluid">
      <?php
         $result = mysqli_query($conn,"SELECT * FROM `employeeform`");
 
      echo '<br><table class="table table-fixed table-striped table-responsive-lg table-hover table-bordered table-responsive">
        <thead class="table-dark">
          <tr>
            <th scope="col">Serial Number</th>
            <th scope="col">Employee Code</th>
            <th scope="col">Full Name</th>
            <th scope="col">Mobile</th>
            <th scope="col">Email</th>
            <th scope="col">Date of Joining</th>
            <th scope="col">Ctc offered</th>
            <th scope="col">Date</th>  
                
          </tr>
        </thead>
        <tbody>';

       while($row = mysqli_fetch_array($result))
       {

        echo '<tr>';
        echo '<td>'.$row['serial_no'].'</td>';
        echo '<td>'.$row['branch_code'].'</td>';
        echo '<td>'.$row['name'].'</td>';
        echo '<td>'.$row['mobile'].'</td>';
        echo '<td>'.$row['email'].'</td>';
        echo '<td>'.$row['doj'].'</td>';
        echo '<td>'.$row['ctc_offered'].'</td>';        
        echo '<td>'.$row['date'].'</td>';
         
        echo '</tr>';
      }
        echo '</tbody>';
      echo '</table>';

      ?>
    </div>
</body>
</html>