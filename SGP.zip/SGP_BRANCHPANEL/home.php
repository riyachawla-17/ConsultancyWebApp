<?php
session_start();
 if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
  {
   header("location:loginPage.php");
   exit;
  }
?>

<!DOCTYPE html>
<html>
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>WELCOME - <?php echo $_SESSION['username'];?></title>
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

   </head>
    <body>
        <?php
           require 'nav.php';
        ?>
       <div class="container my-4">
         <div class="alert alert-success" role="alert">
  <h4 class="alert-heading">WELCOME - <?php echo $_SESSION['username'];?></h4>
  <p>Welcome to DIVINE CONSULTANTS. You are logged in as <?php echo $_SESSION['username'];?></p>
  <hr>
  <p class="mb-0">Whenever you need to, be sure to logout <a href = "/sgp/sgp_branchpanel/logoutPage.php"> using this link.</a></p>
</div>

    </body>
</html>