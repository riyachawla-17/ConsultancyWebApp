<?php
session_start();
 if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
  {
   header("location:/sgp/sgp_branchpanel/loginPage.php");
   exit;
  }
?>
<?php
 $response = false;
 $showError = false;
 if($_SERVER['REQUEST_METHOD'] == "POST")
 {  
    require 'db.php';
    header('refresh:0');
    $branch_code = $_POST['branch_code'];
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $location = $_POST['location'];
    $dob = $_POST['dob'];
    $qualification = $_POST['qualification'];
    $experience = $_POST['experience'];
    $ctc = $_POST['ctc'];
    $job_domain = $_POST['job_domain'];
    $pname = rand(1000,10000)."-".$_FILES["bio_data"]["name"];
    $tname = $_FILES["bio_data"]["tmp_name"];
    $uploads_dir = 'ne';
    move_uploaded_file($tname, $uploads_dir.'/'.$pname);

    $sql = "INSERT INTO `jobform`(`branch_code`, `name`, `mobile`, `email`, `location`, `dob`, `qualification`, `experience`, `ctc`, `job_domain`,`bio_data`,`date`) VALUES ('$branch_code','$name','$mobile','$email','$location','$dob','$qualification','$experience','$ctc','$job_domain','$pname', current_timestamp())"; 
        $result = mysqli_query($conn,$sql);
        if($result)
        {
             $response = true;
        }
        else
        {
             $showError = "Invalid Credentials!".mysqli_error($conn);
        }



  /*   if(isset($_POST['submit']))
     {

    $pname = rand(1000,10000)."-".$_FILES["bio_data"]["name"];
    $tname = $_FILES["bio_data"]["tmp_name"];
    $uploads_dir = 'ne';
    move_uploaded_file($tname, $uploads_dir.'/'.$pname);
    if(mysqli_query($conn,$sql)){

    echo "File Sucessfully uploaded";
    }
    else{
        echo "Error".mysqli_error($conn);
    }
}*/
}

?>
<!DOCTYPE html>
<html>
  <head>
      <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>CREATE JOB LEAD</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!--
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

  </head>
    <body>

        <?php
           require 'nav.php';
        ?>

        <?php
        if($response == true)
        {
          echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>SUCCESS! </strong> Your Lead is created successfully.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
        if($showError == true)
        {
          echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>ERROR!</strong> '. $showError.'
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>';
        }
       ?>

       <div class="container my-4">
       <h1 class="text-center"> Fill up the form </h1>
        <form class="was-validated" action="jobform.php" method="POST" enctype="multipart/form-data">
          <div class="mb-3 form-group">
            <label for="validationtext" class="form-label">Branch Code</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="branch_code" placeholder="BRANCH CODE" required></input>
        </div>


          <div class="mb-3">
            <label for="validationtext" class="form-label">Full Name</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="name" placeholder="FULL NAME" required></input>
          </div>


          <div class="mb-3">
            <label for="validationtext" class="form-label">Mobile</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="mobile" placeholder="Mobile" required></input>
          </div>


          <div class="mb-3">
            <label for="validationtext" class="form-label">Email ID</label>
            <input type="email" class="form-control is-invalid" id="validationtext" name="email" placeholder="EMAIL ID" required></input>
          </div>


          <div class="mb-3">
            <label for="validationtext" class="form-label">LOCATION</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="location" placeholder="LOCATION" required></input>
          </div>


          <div class="mb-3 was-validated">
            <label for="validationtext" class="form-label">DATE OF BIRTH</label>
            <input type="date" class="form-control is-invalid" id="validationtext" name="dob" placeholder="DATE OF BIRTH" required></input>
          </div>


          <div class="mb-3">
            <label for="validationtext" class="form-label">QUALIFICATION</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="qualification" placeholder="QUALIFICATION" required></input>
          </div>


          <div class="mb-3">
            <label for="validationtext" class="form-label">EXPERIENCE(in Years)</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="experience" placeholder="EXPERIENCE(in Years)" required></input>
          </div>



          <div class="mb-3">
            <label for="validationtext" class="form-label">CTC</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="ctc" placeholder="CTC" required></input>
          </div>



          <div class="mb-3">
            <label for="validationtext" class="form-label">JOB DOMAIN</label>
            <input type="text" class="form-control is-invalid" id="validationtext" name="job_domain" placeholder="JOB DOMAIN" required></input>
          </div>

          <div class="mb-3">
            <label for="validationtext" class="form-label">BIO DATA</label>
            <input type="file" class="form-control" id="validationtext" name="bio_data" placeholder="BIO DATA" required></input>

          </div>

          <div class="mb-3">
            <center>
            <button class="btn btn-primary" type="submit" name = "submit">Submit form</button>
            <button class="btn btn-primary" type="cancel">Cancel</button>
        </center>
          </div>


        </form>
    </div
    >
    </body>
</html>
