<?php
if(isset($_SESSION['loggedin']) && ($_SESSION['loggedin'] == true))
  {
    $loggedin = true;
  }
else
{
  $loggedin=false;
}

 echo '<nav class="navbar navbar-expand-lg navbar-dark bg-info">
  <a class="navbar-brand" href="/sgp/sgp_branchpanel">Divine Consultants</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">' ;
if(!$loggedin)
{
      echo '<li class="nav-item">
        <a class="nav-link" href="/sgp/sgp_branchpanel/loginPage.php">LOGIN</a>
      </li>';
}
if($loggedin)
{
      echo '<li class="nav-item active">
        <a class="nav-link" href="/sgp/sgp_branchpanel/home.php"> HOME <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          PARTNER 
         </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="partnerform.php"> CREATE PARTNER </a>
          <a class="dropdown-item" href="view_partnerform.php"> VIEW PARTNER </a>
        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          CREATE PARTNER LEADS
         </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="jobform.php"> JOB LEADS </a>
          <a class="dropdown-item" href="loanform.php"> LOAN LEADS </a>
          <a class="dropdown-item" href="insuranceform.php"> INSURANCE LEADS </a>
          <a class="dropdown-item" href="mutualFundsform.php"> MUTUAL FUNDS LEADS </a>
          <a class="dropdown-item" href="trainingform.php"> COPORATE TRAINING LEADS </a>
        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         VIEW BRANCH LEADS
         </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="view_jobform.php"> JOB LEADS </a>
          <a class="dropdown-item" href="view_loanform.php"> LOAN LEADS </a>
          <a class="dropdown-item" href="view_insuranceform.php"> INSURANCE LEADS </a>
          <a class="dropdown-item" href="view_mutualfundsform.php"> MUTUAL FUNDS LEADS </a>
          <a class="dropdown-item" href="view_trainingform.php"> TRAINING LEADS </a>   
        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         VIEW PARTNER LEADS
         </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="fetchjoblead.php"> JOB LEADS </a>
        <a class="dropdown-item" href="fetchloanlead.php"> LOAN LEADS </a>
        <a class="dropdown-item" href="fetchinsurancelead.php"> INSURANCE LEADS </a>
        <a class="dropdown-item" href="fetchmutualfundlead.php"> MUTUAL FUNDS LEADS </a>
        <a class="dropdown-item" href="fetchtraininglead.php"> COPORATE TRAINING LEADS </a>
        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> 
           PROFILE
         </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#"> VIEW COMMISSION STRUCTURE </a>
          <a class="dropdown-item" href="#"> RESET PASSWORD </a>
          <a class="dropdown-item" href="/sgp/sgp_branchpanel/logoutPage.php"> LOGOUT </a>
        </div>
      </li>
     
      ' ;
}
    echo' </ul>
      </div>
</nav>';
?>