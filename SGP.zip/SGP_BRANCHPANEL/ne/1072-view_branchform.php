<?php
session_start();
 if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
  {
   header("location:loginPage.php");
   exit;
  }
?>
<!DOCTYPE html>
<html>
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title> VIEW BRANCH LEADS </title>
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

   </head>
   <body>
      <?php
         require 'db.php';
         require 'nav.php';
      ?>

<div class="container-fluid">
      <?php
         $result = mysqli_query($conn,"SELECT * FROM `branchform`");
        /* $username = $_POST['username'];
         $password = $_POST['pass1'];
             // $sql = "SELECT * FROM `users` WHERE username='$username' AND password='$password'";
               $sql = "SELECT * FROM `users` WHERE username='$username'";
              $result = mysqli_query($conn,$sql);
              $num = mysqli_num_rows($result);
              if($num == 1)
              {
                  while($row = mysqli_fetch_assoc($result))
                  {
                        if (password_verify($password, $row['password']))
                    {
                      $login = true;
                      session_start();
                      $_SESSION['loggedin'] = true;
                      $_SESSION['username'] = $username;
                      header("location:welcome.php");   
                  }

             else
              {
                  $showError = "Invalid Credentials!";
              }
              }
          }
             else
              {
                  $showError = "Invalid Credentials!";
              }
          }*/
      echo '<br><table class="table table-fixed table-striped table-responsive-lg table-hover table-bordered table-responsive">
        <thead class="table-dark">
          <tr>
            <th scope="col">Serial Number</th>
            <th scope="col">Branch Code</th>
            <th scope="col">Full Name</th>
            <th scope="col">Business Name</th>
            <th scope="col">Mobile</th>
            <th scope="col">Email</th>
            <th scope="col">Address</th>
            <th scope="col">City</th>
            <th scope="col">State</th>
            <th scope="col">Pin Code</th>
            <th scope="col">IFSC Code</th>
            <th scope="col">Bank Acount Name</th>
            <th scope="col">Bank Acount Number</th>
            <th scope="col">Acount Type</th>         
            <th scope="col">Date</th>  
                
          </tr>
        </thead>
        <tbody>';

       while($row = mysqli_fetch_array($result))
       {

        echo '<tr>';
        echo '<td>'.$row['serial_no'].'</td>';
        echo '<td>'.$row['branch_code'].'</td>';
        echo '<td>'.$row['name'].'</td>';
        echo '<td>'.$row['business_name'].'</td>';
        echo '<td>'.$row['mobile'].'</td>';
        echo '<td>'.$row['email'].'</td>';
        echo '<td>'.$row['address'].'</td>';
        echo '<td>'.$row['city'].'</td>';        
        echo '<td>'.$row['state'].'</td>';
        echo '<td>'.$row['pin_code'].'</td>';
        echo '<td>'.$row['ifsc_code'].'</td>';
        echo '<td>'.$row['bank_acc_name'].'</td>';
        echo '<td>'.$row['bank_acc_no'].'</td>';
        echo '<td>'.$row['acc_type'].'</td>';
        echo '<td>'.$row['date'].'</td>';
         
        echo '</tr>';
      }
         /*<tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td colspan="2">Larry the Bird</td>
            <td>@twitter</td>
          </tr>*/
        echo '</tbody>';
      echo '</table>';

      ?>
    </div>
</body>
</html>